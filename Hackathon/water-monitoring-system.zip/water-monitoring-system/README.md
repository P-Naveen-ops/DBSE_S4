# Water Consumption Monitoring System

Track water use across buildings, apartments or campus facilities: buildings, meters, daily readings, consumption history and alerts.

| Layer | Technology |
|---|---|
| Backend | Java 17, Spring Boot 3 (REST API), Spring Data JPA |
| Database | PostgreSQL 16 |
| Frontend | HTML/CSS/JavaScript calling the REST API with `fetch` (Chart.js for the graph) |
| Python component | `anomaly-detector/detect.py` - robust z-score abnormal consumption detection |

## Run it
1. Start PostgreSQL: `docker compose up -d db`
   (or create a database `water_db` yourself and set `DB_URL`, `DB_USER`, `DB_PASSWORD`).
2. Start the backend: `cd backend && mvn spring-boot:run`
3. Open http://localhost:8080 (tables are created automatically and demo data is loaded on first start).
4. Run the Python detector: `cd anomaly-detector && pip install -r requirements.txt && python detect.py`

## REST API
| Method | Path | Purpose |
|---|---|---|
| GET/POST/DELETE | `/api/buildings` | Manage buildings |
| GET/POST/DELETE | `/api/meters?buildingId=` | Manage meters |
| GET/POST | `/api/readings?meterId=&days=` | Consumption history / add a reading (Java also auto-flags spikes) |
| GET/POST | `/api/alerts` | List alerts / create alert (used by Python) |
| PUT | `/api/alerts/{id}/resolve` | Resolve an alert |
| GET | `/api/dashboard` | Totals and 14-day consumption series |

The frontend lives in `backend/src/main/resources/static` and only talks to `/api`. To host it separately, set `window.API_BASE = "http://localhost:8080/api"` before `app.js` loads (CORS is enabled).
