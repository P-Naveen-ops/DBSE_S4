const API = window.API_BASE || '/api';
const $ = id => document.getElementById(id);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let chart, meters = [];

async function api(path, method = 'GET', body) {
  const res = await fetch(API + path, {
    method, headers: {'Content-Type': 'application/json'},
    body: body ? JSON.stringify(body) : undefined
  });
  const text = await res.text();
  const data = text ? JSON.parse(text) : null;
  if (!res.ok) throw new Error((data && data.error) || 'Request failed (' + res.status + ')');
  return data;
}
function say(text, ok) {
  const m = $('msg'); m.textContent = text; m.className = text ? (ok ? 'ok' : 'err') : '';
  if (text) setTimeout(() => say(''), 4000);
}
const run = fn => async (...a) => { try { await fn(...a); } catch (e) { say(e.message); } };

/* ---------- tabs ---------- */
document.querySelectorAll('nav button').forEach(b => b.onclick = run(async () => {
  document.querySelectorAll('nav button').forEach(x => x.classList.toggle('on', x === b));
  document.querySelectorAll('.tab').forEach(t => t.hidden = t.id !== b.dataset.tab);
  await loaders[b.dataset.tab]();
}));

/* ---------- dashboard ---------- */
async function loadDashboard() {
  const d = await api('/dashboard');
  const n = Math.round(d.last7DaysLiters).toLocaleString('en-IN');
  $('odo').innerHTML = [...n].map(c => `<span class="${/\d/.test(c) ? '' : 'sep'}">${esc(c)}</span>`).join('');
  $('fB').textContent = d.buildings; $('fM').textContent = d.meters; $('fA').textContent = d.openAlerts;
  setBadge(d.openAlerts);
  const labels = d.dailySeries.map(p => p.date.slice(5)), data = d.dailySeries.map(p => p.liters);
  if (chart) chart.destroy();
  chart = new Chart($('chart'), {
    type: 'bar',
    data: {labels, datasets: [{label: 'Litres', data, backgroundColor: '#1e7f8c', borderRadius: 3}]},
    options: {maintainAspectRatio: false, plugins: {legend: {display: false}}, scales: {y: {beginAtZero: true}}}
  });
}
function setBadge(n) { const b = $('badge'); b.hidden = !n; b.textContent = n; }

/* ---------- buildings ---------- */
async function loadBuildings() {
  const rows = await api('/buildings');
  $('bBody').innerHTML = rows.length ? rows.map(b => `<tr><td>${esc(b.name)}</td><td>${esc(b.type)}</td><td>${esc(b.address)}</td>
    <td><button class="link" onclick="del('/buildings/${b.id}',loadBuildings)">Delete</button></td></tr>`).join('')
    : '<tr><td colspan="4" class="empty">No buildings yet. Add your first building above.</td></tr>';
}
$('addB').onclick = run(async () => {
  await api('/buildings', 'POST', {name: $('bName').value.trim(), type: $('bType').value, address: $('bAddr').value.trim()});
  $('bName').value = ''; $('bAddr').value = ''; say('Building added', true); await loadBuildings();
});

/* ---------- meters ---------- */
async function loadMeters() {
  const [b, m] = await Promise.all([api('/buildings'), api('/meters')]);
  meters = m;
  $('mBuilding').innerHTML = b.map(x => `<option value="${x.id}">${esc(x.name)}</option>`).join('');
  $('mBody').innerHTML = m.length ? m.map(x => `<tr><td>${esc(x.meterCode)}</td><td>${esc(x.location)}</td><td>${esc(x.building.name)}</td>
    <td><button class="link" onclick="del('/meters/${x.id}',loadMeters)">Delete</button></td></tr>`).join('')
    : '<tr><td colspan="4" class="empty">No meters yet. Add a building first, then add a meter.</td></tr>';
}
$('addM').onclick = run(async () => {
  await api('/meters', 'POST', {meterCode: $('mCode').value.trim(), location: $('mLoc').value.trim(), building: {id: +$('mBuilding').value}});
  $('mCode').value = ''; $('mLoc').value = ''; say('Meter added', true); await loadMeters();
});

/* ---------- readings ---------- */
async function loadReadings() {
  meters = await api('/meters');
  const opts = meters.map(m => `<option value="${m.id}">${esc(m.meterCode)} - ${esc(m.building.name)}</option>`).join('');
  const keep = $('rFilter').value;
  $('rMeter').innerHTML = opts;
  $('rFilter').innerHTML = '<option value="">All meters</option>' + opts;
  $('rFilter').value = keep;
  if (!$('rDate').value) $('rDate').value = new Date().toISOString().slice(0, 10);
  const q = $('rFilter').value ? '&meterId=' + $('rFilter').value : '';
  const rows = await api('/readings?days=30' + q);
  $('rBody').innerHTML = rows.length ? rows.map(r => `<tr><td>${esc(r.readingDate)}</td><td>${esc(r.meter.meterCode)}</td>
    <td>${esc(r.meter.building.name)}</td><td class="num">${Math.round(r.liters).toLocaleString('en-IN')}</td></tr>`).join('')
    : '<tr><td colspan="4" class="empty">No readings in the last 30 days.</td></tr>';
}
$('rFilter').onchange = run(loadReadings);
$('addR').onclick = run(async () => {
  if ($('rLiters').value === '') throw new Error('Enter the litres used.');
  await api('/readings', 'POST', {meter: {id: +$('rMeter').value}, readingDate: $('rDate').value, liters: +$('rLiters').value});
  $('rLiters').value = ''; say('Reading saved', true); await loadReadings(); refreshBadge();
});

/* ---------- alerts ---------- */
async function loadAlerts() {
  const rows = await api('/alerts');
  setBadge(rows.filter(a => !a.resolved).length);
  $('aBody').innerHTML = rows.length ? rows.map(a => `<tr><td>${esc(a.readingDate || '')}</td><td>${esc(a.meter.meterCode)}</td>
    <td>${a.type === 'SPIKE' ? 'Spike rule (Java)' : 'Statistical check (Python)'}</td><td>${esc(a.message)}</td>
    <td><span class="tag ${a.resolved ? '' : 'open'}">${a.resolved ? 'Resolved' : 'Open'}</span></td>
    <td>${a.resolved ? '' : `<button class="link ok" onclick="resolveAlert(${a.id})">Mark resolved</button>`}</td></tr>`).join('')
    : '<tr><td colspan="6" class="empty">No alerts. Abnormal consumption will appear here.</td></tr>';
}
window.resolveAlert = run(async id => { await api('/alerts/' + id + '/resolve', 'PUT'); say('Alert resolved', true); await loadAlerts(); });
window.del = run(async (path, reload) => {
  if (!confirm('Delete this record?')) return;
  await api(path, 'DELETE'); say('Deleted', true); await reload();
});
window.loadBuildings = loadBuildings; window.loadMeters = loadMeters;
async function refreshBadge() { try { setBadge((await api('/dashboard')).openAlerts); } catch (e) {} }

const loaders = {dashboard: loadDashboard, buildings: loadBuildings, meters: loadMeters, readings: loadReadings, alerts: loadAlerts};
run(loadDashboard)();
