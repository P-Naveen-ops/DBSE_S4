package com.water.monitor;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity @Table(name = "buildings") @Getter @Setter
public class Building {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false)
    private String name;
    private String type;     // BUILDING, APARTMENT, CAMPUS
    private String address;
}
