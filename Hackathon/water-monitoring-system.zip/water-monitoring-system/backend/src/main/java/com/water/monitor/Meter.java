package com.water.monitor;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity @Table(name = "meters") @Getter @Setter
public class Meter {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, unique = true)
    private String meterCode;
    private String location;
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    private Building building;
}
