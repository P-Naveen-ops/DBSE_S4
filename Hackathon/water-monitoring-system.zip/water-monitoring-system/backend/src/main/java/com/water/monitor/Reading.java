package com.water.monitor;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.time.LocalDate;

/** One consumption reading: litres used by a meter on a given day. */
@Entity @Table(name = "readings", indexes = @Index(columnList = "meter_id, readingDate"))
@Getter @Setter
public class Reading {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    private Meter meter;
    @Column(nullable = false)
    private LocalDate readingDate;
    @Column(nullable = false)
    private double liters;
}
