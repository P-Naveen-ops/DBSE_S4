package com.water.monitor;

import lombok.RequiredArgsConstructor;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.context.annotation.Configuration;

import java.time.LocalDate;
import java.util.*;

@Configuration
class CorsConfig implements WebMvcConfigurer {
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/api/**").allowedOrigins("*").allowedMethods("GET", "POST", "PUT", "DELETE");
    }
}

@RestControllerAdvice
class ApiErrors {
    @ExceptionHandler(DataIntegrityViolationException.class)
    ResponseEntity<Map<String, String>> conflict(DataIntegrityViolationException e) {
        return ResponseEntity.status(HttpStatus.CONFLICT)
                .body(Map.of("error", "Cannot save or delete: the record is duplicated or still in use."));
    }
    @ExceptionHandler(IllegalArgumentException.class)
    ResponseEntity<Map<String, String>> bad(IllegalArgumentException e) {
        return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
    }
}

@RestController @RequestMapping("/api/buildings") @RequiredArgsConstructor
class BuildingController {
    private final BuildingRepo repo;

    @GetMapping public List<Building> all() { return repo.findAll(); }

    @PostMapping public Building create(@RequestBody Building b) {
        if (b.getName() == null || b.getName().isBlank()) throw new IllegalArgumentException("Building name is required.");
        b.setId(null);
        return repo.save(b);
    }

    @DeleteMapping("/{id}") public void delete(@PathVariable Long id) { repo.deleteById(id); }
}

@RestController @RequestMapping("/api/meters") @RequiredArgsConstructor
class MeterController {
    private final MeterRepo repo;

    @GetMapping public List<Meter> all(@RequestParam(required = false) Long buildingId) {
        return buildingId == null ? repo.findAll() : repo.findByBuildingId(buildingId);
    }

    @PostMapping public Meter create(@RequestBody Meter m) {
        if (m.getMeterCode() == null || m.getMeterCode().isBlank()) throw new IllegalArgumentException("Meter code is required.");
        if (m.getBuilding() == null || m.getBuilding().getId() == null) throw new IllegalArgumentException("Choose a building.");
        m.setId(null);
        return repo.save(m);
    }

    @DeleteMapping("/{id}") public void delete(@PathVariable Long id) { repo.deleteById(id); }
}

@RestController @RequestMapping("/api/readings") @RequiredArgsConstructor
class ReadingController {
    private final ReadingRepo readings;
    private final AlertRepo alerts;

    @GetMapping public List<Reading> history(@RequestParam(required = false) Long meterId,
                                             @RequestParam(defaultValue = "30") int days) {
        LocalDate from = LocalDate.now().minusDays(days);
        return meterId == null
                ? readings.findByReadingDateGreaterThanEqualOrderByReadingDateDesc(from)
                : readings.findByMeterIdAndReadingDateGreaterThanEqualOrderByReadingDateDesc(meterId, from);
    }

    @PostMapping public Reading add(@RequestBody Reading r) {
        if (r.getMeter() == null || r.getMeter().getId() == null) throw new IllegalArgumentException("Choose a meter.");
        if (r.getReadingDate() == null) throw new IllegalArgumentException("Reading date is required.");
        if (r.getLiters() < 0) throw new IllegalArgumentException("Litres cannot be negative.");
        r.setId(null);
        Reading saved = readings.save(r);
        checkForSpike(saved);
        return saved;
    }

    /** Built-in rule: flag a reading more than 1.5x the meter's recent average (needs 5+ earlier readings). */
    private void checkForSpike(Reading r) {
        List<Reading> prev = readings.findTop14ByMeterIdAndReadingDateLessThanOrderByReadingDateDesc(
                r.getMeter().getId(), r.getReadingDate());
        if (prev.size() < 5) return;
        double avg = prev.stream().mapToDouble(Reading::getLiters).average().orElse(0);
        if (r.getLiters() > avg * 1.5 && r.getLiters() - avg > 50) {
            Alert a = new Alert();
            a.setMeter(r.getMeter());
            a.setType("SPIKE");
            a.setReadingDate(r.getReadingDate());
            a.setLiters(r.getLiters());
            a.setMessage(String.format("%.0f L is well above the recent average of %.0f L.", r.getLiters(), avg));
            alerts.save(a);
        }
    }
}

@RestController @RequestMapping("/api/alerts") @RequiredArgsConstructor
class AlertController {
    private final AlertRepo repo;

    @GetMapping public List<Alert> all() { return repo.findAllByOrderByCreatedAtDesc(); }

    /** Used by the Python anomaly detector. */
    @PostMapping public Alert create(@RequestBody Alert a) {
        if (a.getMeter() == null || a.getMeter().getId() == null) throw new IllegalArgumentException("Meter is required.");
        a.setId(null);
        a.setResolved(false);
        a.setCreatedAt(java.time.LocalDateTime.now());
        return repo.save(a);
    }

    @PutMapping("/{id}/resolve") public Alert resolve(@PathVariable Long id) {
        Alert a = repo.findById(id).orElseThrow(() -> new IllegalArgumentException("Alert not found."));
        a.setResolved(true);
        return repo.save(a);
    }
}

@RestController @RequestMapping("/api/dashboard") @RequiredArgsConstructor
class DashboardController {
    private final BuildingRepo buildings;
    private final MeterRepo meters;
    private final AlertRepo alerts;
    private final ReadingRepo readings;

    @GetMapping public Map<String, Object> summary() {
        LocalDate from = LocalDate.now().minusDays(13);
        List<Map<String, Object>> series = new ArrayList<>();
        double last7 = 0;
        for (Object[] row : readings.dailyTotals(from)) {
            LocalDate d = (LocalDate) row[0];
            double liters = ((Number) row[1]).doubleValue();
            series.add(Map.of("date", d.toString(), "liters", liters));
            if (!d.isBefore(LocalDate.now().minusDays(6))) last7 += liters;
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("buildings", buildings.count());
        m.put("meters", meters.count());
        m.put("openAlerts", alerts.countByResolvedFalse());
        m.put("last7DaysLiters", last7);
        m.put("dailySeries", series);
        return m;
    }
}
