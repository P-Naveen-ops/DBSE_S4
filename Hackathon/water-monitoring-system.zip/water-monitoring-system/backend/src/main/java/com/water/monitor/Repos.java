package com.water.monitor;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.time.LocalDate;
import java.util.List;

interface BuildingRepo extends JpaRepository<Building, Long> {}

interface MeterRepo extends JpaRepository<Meter, Long> {
    List<Meter> findByBuildingId(Long buildingId);
}

interface ReadingRepo extends JpaRepository<Reading, Long> {
    List<Reading> findByMeterIdAndReadingDateGreaterThanEqualOrderByReadingDateDesc(Long meterId, LocalDate from);
    List<Reading> findByReadingDateGreaterThanEqualOrderByReadingDateDesc(LocalDate from);
    List<Reading> findTop14ByMeterIdAndReadingDateLessThanOrderByReadingDateDesc(Long meterId, LocalDate before);

    @Query("select r.readingDate, sum(r.liters) from Reading r where r.readingDate >= :from group by r.readingDate order by r.readingDate")
    List<Object[]> dailyTotals(@Param("from") LocalDate from);
}

interface AlertRepo extends JpaRepository<Alert, Long> {
    List<Alert> findAllByOrderByCreatedAtDesc();
    long countByResolvedFalse();
}
