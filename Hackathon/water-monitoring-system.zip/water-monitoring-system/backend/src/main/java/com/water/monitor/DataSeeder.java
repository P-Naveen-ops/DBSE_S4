package com.water.monitor;

import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.Random;

/** Loads demo data on first start so the dashboard is not empty. */
@Component @RequiredArgsConstructor
class DataSeeder implements CommandLineRunner {
    private final BuildingRepo buildings;
    private final MeterRepo meters;
    private final ReadingRepo readings;
    private final AlertRepo alerts;

    @Override public void run(String... args) {
        if (buildings.count() > 0) return;
        Building a = building("Sunrise Apartments", "APARTMENT", "12 Lake Road");
        Building b = building("Engineering Block", "BUILDING", "North Campus");
        Building c = building("Student Hostel", "CAMPUS", "South Campus");
        Meter m1 = meter("MTR-001", "Main inlet", a);
        Meter m2 = meter("MTR-002", "Lab wing", b);
        Meter m3 = meter("MTR-003", "Kitchen and mess", c);
        Random rnd = new Random(7);
        double[] base = {900, 650, 1400};
        Meter[] all = {m1, m2, m3};
        for (int i = 0; i < 3; i++) {
            for (int d = 30; d >= 1; d--) {
                Reading r = new Reading();
                r.setMeter(all[i]);
                r.setReadingDate(LocalDate.now().minusDays(d));
                double v = base[i] * (0.9 + rnd.nextDouble() * 0.2);
                if (i == 0 && d == 2) v = base[i] * 2.6;   // simulated leak
                r.setLiters(Math.round(v));
                readings.save(r);
            }
        }
        Alert al = new Alert();
        al.setMeter(m1); al.setType("SPIKE"); al.setReadingDate(LocalDate.now().minusDays(2));
        al.setLiters(2340.0); al.setMessage("2340 L is well above the recent average of 900 L.");
        alerts.save(al);
    }

    private Building building(String n, String t, String ad) {
        Building x = new Building(); x.setName(n); x.setType(t); x.setAddress(ad); return buildings.save(x);
    }
    private Meter meter(String code, String loc, Building bd) {
        Meter x = new Meter(); x.setMeterCode(code); x.setLocation(loc); x.setBuilding(bd); return meters.save(x);
    }
}
