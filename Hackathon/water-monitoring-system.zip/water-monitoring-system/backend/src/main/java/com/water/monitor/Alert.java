package com.water.monitor;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity @Table(name = "alerts") @Getter @Setter
public class Alert {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    private Meter meter;
    private String type;           // SPIKE (Java rule) or PYTHON_ZSCORE (Python detector)
    @Column(length = 500)
    private String message;
    private LocalDate readingDate;
    private Double liters;
    private boolean resolved = false;
    private LocalDateTime createdAt = LocalDateTime.now();
}
