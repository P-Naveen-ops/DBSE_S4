"""
Abnormal water-consumption detector (Python component).

Pulls meters and readings from the Spring Boot API, scores each reading with a
robust z-score (median / MAD), and posts an alert for every abnormal reading
that has not been reported yet.

Usage:  python detect.py [--api http://localhost:8080/api] [--days 60] [--threshold 3.5]
"""
import argparse
import statistics
import requests


def robust_z(value, values):
    median = statistics.median(values)
    mad = statistics.median(abs(v - median) for v in values)
    if mad == 0:
        return 0.0
    return 0.6745 * (value - median) / mad


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--api", default="http://localhost:8080/api")
    p.add_argument("--days", type=int, default=60)
    p.add_argument("--threshold", type=float, default=3.5)
    args = p.parse_args()

    meters = requests.get(f"{args.api}/meters", timeout=10).json()
    existing = {
        (a["meter"]["id"], a.get("readingDate"))
        for a in requests.get(f"{args.api}/alerts", timeout=10).json()
    }

    created = 0
    for m in meters:
        rows = requests.get(f"{args.api}/readings",
                            params={"meterId": m["id"], "days": args.days}, timeout=10).json()
        if len(rows) < 7:
            continue
        values = [r["liters"] for r in rows]
        for r in rows:
            z = robust_z(r["liters"], values)
            if z > args.threshold and (m["id"], r["readingDate"]) not in existing:
                median = statistics.median(values)
                alert = {
                    "meter": {"id": m["id"]},
                    "type": "PYTHON_ZSCORE",
                    "readingDate": r["readingDate"],
                    "liters": r["liters"],
                    "message": f"Abnormal usage: {r['liters']:.0f} L vs typical {median:.0f} L (score {z:.1f}).",
                }
                requests.post(f"{args.api}/alerts", json=alert, timeout=10).raise_for_status()
                created += 1
                print(f"ALERT {m['meterCode']} {r['readingDate']} {r['liters']:.0f} L (z={z:.1f})")
    print(f"Done. {created} new alert(s).")


if __name__ == "__main__":
    main()
